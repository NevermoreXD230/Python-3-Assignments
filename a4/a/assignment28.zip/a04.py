### YOUR CODE FOR openLocks() FUNCTION GOES HERE ###


#### End OF MARKER





### YOUR CODE FOR mostTouchableLocker() FUNCTION GOES HERE ###


#### End OF MARKER


