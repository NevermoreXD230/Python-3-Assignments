### YOUR CODE FOR chocolatePrice() FUNCTION GOES HERE ###


#### End OF MARKER





### YOUR CODE FOR calculateProfit() FUNCTION GOES HERE ###


#### End OF MARKER


